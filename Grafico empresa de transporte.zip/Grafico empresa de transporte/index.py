from flask import Flask, render_template
import plotly.express as px
import plotly.io as pio
import pandas as pd

app = Flask(__name__)

@app.route('/')
def index():
    # Dados fictícios sobre a produção da empresa de transporte
    data = {
        'Data': ['2023-01-01', '2023-01-02', '2023-01-03'],
        'Entregas Realizadas': [150, 200, 180],
        'Entregas Pendentes': [30, 15, 25],
        'Km Percorridos': [1200, 1500, 1400]
    }

    # Crie um DataFrame a partir dos dados
    df = pd.DataFrame(data)

    # Crie gráficos usando a biblioteca Plotly Express
    fig1 = px.bar(df, x='Data', y=['Entregas Realizadas', 'Entregas Pendentes'], title='Entregas Diárias')
    fig2 = px.line(df, x='Data', y='Km Percorridos', title='Quilômetros Percorridos Diariamente')

    # Salve os gráficos em formato HTML
    pio.write_html(fig1, file='templates/grafico1.html', full_html=False)
    pio.write_html(fig2, file='templates/grafico2.html', full_html=False)

    # Renderize a página HTML com os gráficos
    return render_template('dashboard.html')


if __name__ == '__main__':
    app.run(debug=True)
